const canvas = document.querySelector('canvas');
const context = canvas.getContext('2d');
const fillS = document.querySelector('.tools .fillS');
const strokeS = document.querySelector('.tools .strokeS');
const eraser = document.querySelector('.tools .eraser');
const strokeC = document.querySelector('.tools .strokeC');
const fillC = document.querySelector('.tools .fillC');
const clearAll = document.querySelector('.tools .clearAll');

let pic = 0;
let bool = false;
let draw = {
    w: 30,
    h: 30
}
fillS.onclick = (e) => pic = 0;
strokeS.onclick = () => pic = 1;
eraser.onclick = () => pic = 2;
strokeC.onclick = () => pic = 3;
fillC.onclick = () => pic = 4;
clearAll.onclick = () => pic = context.clearRect(0, 0, canvas.width, canvas.height);

size.oninput = () => {
    draw.w = size.value;
    draw.h = size.value;
    sizeInfo.textContent = size.value + 'px';
}

document.onmousedown = (e) => {
    bool = true;
    colorPicker.oninput = () => {
        colorPick1.checked ? context.fillStyle = colorPicker.value : false;
        colorPick2.checked ? canvas.style.background = colorPicker.value : false;
    }
    if (pic == 0) {
        bool ? context.fillRect(e.clientX - 290 - draw.w / 2, e.clientY - 29 - draw.h / 2, draw.w, draw.h) : '';
        document.onmousemove = (e) => {
            bool ? context.fillRect(e.clientX - 290 - draw.w / 2, e.clientY - 29 - draw.h / 2, draw.w, draw.h) : '';
        }
    } else if (pic == 1) {
        bool ? context.strokeRect(e.clientX - 290 - draw.w / 2, e.clientY - 29 - draw.h / 2, draw.w, draw.h) : '';
        document.onmousemove = (e) => {
            bool ? context.strokeRect(e.clientX - 290 - draw.w / 2, e.clientY - 29 - draw.h / 2, draw.w, draw.h) : '';
        }
    } else if (pic == 2) {
        bool ? context.clearRect(e.clientX - 290 - draw.w / 2, e.clientY - 29 - draw.h / 2, draw.w, draw.h) : '';
        document.onmousemove = (e) => {
            bool ? context.clearRect(e.clientX - 290 - draw.w / 2, e.clientY - 29 - draw.h / 2, draw.w, draw.h) : '';
        }
    } else if (pic == 3) {
        context.beginPath();
        bool ? context.arc(e.clientX - 290 - draw.w / 2, e.clientY - 29 - draw.h / 2, draw.w, draw.h, Math.PI * 2, true) : '';
        document.onmousemove = (e) => {
            bool ? context.arc(e.clientX - 290 - draw.w / 2, e.clientY - 29 - draw.h / 2, draw.w, draw.h, Math.PI * 2, true) : '';
            context.stroke();
        }
        context.stroke();
    } else if (pic == 4) {
        context.beginPath();
        bool ? context.arc(e.clientX - 290 - draw.w / 2, e.clientY - 29 - draw.h / 2, draw.w, draw.h, Math.PI * 2, true) : '';
        document.onmousemove = (e) => {
            context.fill();
            bool ? context.arc(e.clientX - 290 - draw.w / 2, e.clientY - 29 - draw.h / 2, draw.w, draw.h, Math.PI * 2, true) : '';
        }
        context.fill();
    } else if (pic == 5) {
        context.beginPath();
        bool ? context.arc(e.clientX - 290 - draw.w / 2, e.clientY - 29 - draw.h / 2, draw.w, draw.h, Math.PI * 2, true) : '';
        document.onmousemove = (e) => {
            context.fill();
            bool ? context.arc(e.clientX - 290 - draw.w / 2, e.clientY - 29 - draw.h / 2, draw.w, draw.h, Math.PI * 2, true) : '';
        }
    }
}
document.onmouseup = () => bool = false;
